WalletFeed press kit
https://walletfeed.app/press/

Screenshots are 1320 x 2868 px, from an iPhone 17 Pro Max, with sample data. You may use these images
to write about WalletFeed. Contact: support@walletfeed.app

screenshots/walletfeed-01-ask-spending.png
   Ask Spending. Ask in your own words, such as “Dining this month vs last”. WalletFeed charts the answer and Apple Intelligence on the iPhone sums it up.
   Alt text: The Spending screen after the question “Dining this month vs last”: $172.75 across 8 transactions, a line chart of this month against last month, and a summary that says dining is 27% higher than at this point last month.

screenshots/walletfeed-02-monthly-summary.png
   Spending and Monthly Summary. This month by day, against the same point last month, with the Apple Card balance and due date, and a short summary of the month.
   Alt text: The Spending screen for November: $1,279.93 spent, 75% more than in October, a bar chart by day, the card balance of $1,291.12 due December 7, and a summary that travel is up $175 and the largest purchase was $389 at United Airlines.

screenshots/walletfeed-03-accounts.png
   Accounts. Apple Card, Apple Cash and Savings on the Spending screen, each with its balance and its trend.
   Alt text: The Accounts section of Spending: Apple Card at $1,291.12, Apple Cash at $142.50 and Savings at $5,230.18, each with a small chart of its balance, above the month's categories.

screenshots/walletfeed-04-account.png
   An account’s own screen. A balance over a week to a year, with available credit, the minimum payment and what was spent this month.
   Alt text: The Apple Card screen: a three-month chart of the balance, now $1,291.12, with a low of $331.12 and a high of $1,434.12, then available credit of $6,708.88 of an $8,000 limit, a minimum payment of $35.00 due December 7 and $1,262.03 spent this month.

screenshots/walletfeed-05-search.png
   Search. Type “Groceries over $50 in the last 30 days”. Apple Intelligence reads the request, and WalletFeed shows the transactions and their total.
   Alt text: Search results for groceries over $50.00 in the last 30 days: 4 transactions totalling $277.57, at Whole Foods Market and Safeway, grouped by month.

screenshots/walletfeed-06-transactions.png
   Transactions. Every transaction from the Wallet accounts you share, grouped by month, with pending charges marked.
   Alt text: The Transactions screen for November: Blue Bottle Coffee $6.75 pending, Whole Foods Market $84.12, Tartine Bakery $12.40 from Apple Cash, Uber $23.40, Shell $52.08 and others, each with a category icon and its day.

screenshots/walletfeed-07-subscriptions.png
   Subscriptions. Every charge that repeats: what they cost each month and each year, where the money goes, and when each is next due.
   Alt text: The Subscriptions screen: $123.88 each month and $1,486.56 each year, split between Utilities and Subscriptions, then PG&E at $96.40 a month next due December 6, Netflix at $15.49 and Spotify at $11.99.

screenshots/walletfeed-08-recurring-charges.png
   Recurring Charges and merchants. Recurring charges with the names Apple Intelligence suggests, the month’s top merchants, and the Tax Pack.
   Alt text: Spending scrolled to Recurring Charges, with Netflix and Spotify named and All Subscriptions below them, then Merchants led by United Airlines at $389.20, and Tax Reports with the Tax Pack for 2026.

screenshots/walletfeed-09-tax-pack.png
   Tax Pack. A year’s totals for each account: purchases, refunds, interest and fees. The totals are free to see.
   Alt text: The Tax Pack for 2026 with 45 transactions: for Apple Card, purchases of $2,189.49 and refunds of $49.00, with interest charged, fees and payments to the card at $0.00, then Apple Cash and Savings.

screenshots/walletfeed-10-tax-pack-share.png
   Share the Tax Pack. With Pro Yearly or Lifetime, share the year as a PDF, a summary for an AI assistant and two CSV files.
   Alt text: The foot of the Tax Pack: Savings interest earned of $14.82, then Share Pack and Share Summary for AI, with the note that the pack is a PDF, a Markdown summary for AI and two CSV files, and that WalletFeed doesn’t give tax advice.

screenshots/walletfeed-11-destinations.png
   Destinations. Each place your transactions go, with the time of its last sync.
   Alt text: The Destinations screen with four destinations: Lunch Money, a Google Sheets spreadsheet named Budget 2026, a monthly CSV file and an n8n webhook, each synced minutes ago.

screenshots/walletfeed-12-add-destination.png
   Add Destination. Budgeting apps, accounting, spreadsheets, databases, automations, files and developer tools, each with its own logo.
   Alt text: The Add Destination list: under Budgeting, BankSync, Lunch Money, PocketSmith, Firefly III, Sure, Toshl Finance, Wallet by BudgetBakers, YNAB and QuickBooks Online, then Sheets & Databases starting with Google Sheets.

screenshots/walletfeed-13-google-sheets.png
   Set up Google Sheets. Sign in with Google, name the spreadsheet, and choose Summary Tabs for totals by month, category and merchant.
   Alt text: The Google Sheets form: Sign In with Google, a Spreadsheet named WalletFeed Transactions, a Summary Tabs switch, and three steps that end with tapping Add.

screenshots/walletfeed-14-consent.png
   What a destination receives. Before anything is sent, WalletFeed lists the fields the destination will receive, from which accounts and from when.
   Alt text: An alert over the Webhook form, “Send Transactions to Your Server?”, listing the date, merchant, amount, category, status, account name and the other fields, from Apple Card, Apple Cash and Savings, with Cancel and Send.

screenshots/walletfeed-15-send-history.png
   Send History. A new destination also gets your earlier transactions, at a pace the service accepts.
   Alt text: A Google Sheets destination named Budget 2026 while it sends history: a progress bar at 27 of 46, now at November 2026, with Send History, Send Test and Delete below.

screenshots/walletfeed-16-automations.png
   Automations. A Shortcuts automation syncs seconds after each card tap, and another once a day.
   Alt text: The Automations screen: After Each Card Tap, with steps to copy a description, open Shortcuts and paste it, then Every Day at 9 PM, each with the time of its last run.

screenshots/walletfeed-17-background-sync.png
   Background Sync and notifications. Destinations update within the hour while WalletFeed is closed. Reminders and alerts are optional.
   Alt text: Settings with Background Sync on, Automations, Remind If Sync Stops, Failure Alerts, Initial History set to All and Sync Now, then Require Face ID and Summarize Spending.

screenshots/walletfeed-18-export-csv.png
   Export CSV. A CSV file of this month, last month, 90 days, a year or everything. Free.
   Alt text: The Export CSV screen: Range set to This Month, 28 transactions, and an Export button.

screenshots/walletfeed-19-privacy.png
   Privacy. The privacy statement is in the app: what WalletFeed reads, what stays on the iPhone, and what a destination gets.
   Alt text: The Privacy screen: WalletFeed needs no account and no WalletFeed server keeps your transactions or keys, then sections on Wallet data and on the data kept on your iPhone.

screenshots/walletfeed-20-wallet-access.png
   Share Wallet Data. iOS asks which Wallet accounts WalletFeed can read. You can change it at any time in Settings.
   Alt text: The iOS sheet Share Wallet Data for WalletFeed, with switches for Apple Card, Apple Cash and Savings, and the buttons Share and Don’t Share.

screenshots/walletfeed-21-welcome.png
   Welcome. The first screen: Ask Spending, Destinations, On-Device Privacy and Background Sync.
   Alt text: The Welcome to WalletFeed screen with four points, Ask Spending, Destinations, On-Device Privacy and Background Sync, and a Continue button.

screenshots/walletfeed-22-walletfeed-pro.png
   WalletFeed Pro. Destinations, Background Sync, Send History and the Tax Pack’s files. Yearly, Monthly or Lifetime, with a free trial on the subscriptions.
   Alt text: The WalletFeed Pro screen: Destinations, Background Sync, Send History and Tax Pack, then Yearly at $4.99 a year, Monthly at $0.99 a month and Lifetime at $19.99, with a Start Free Trial button.

logos/walletfeed-icon-1024.png
   App icon, 1024 × 1024 px, square
   Alt text: The WalletFeed app icon: a blue card with a chip, and a round sync symbol, on a near-black square.

logos/walletfeed-banner-1500x500.png
   Banner with the name, 1500 × 500 px
   Alt text: A blue banner with the WalletFeed icon, the name WalletFeed and the line “Spending for Apple Card, Apple Cash and Savings, with Apple Intelligence.”

logos/walletfeed-header-3840x1646.png
   Header art without text, 3840 × 1646 px
   Alt text: Three cards and the sync symbol on a deep blue background, with no text.

logos/walletfeed-icon-rounded-1024.png
   App icon, 1024 x 1024 px, rounded, transparent corners
   Alt text: The WalletFeed app icon with rounded corners on a transparent background.
